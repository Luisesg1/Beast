// functions/index.js
// Deploy: firebase deploy --only functions
//
// Esta función es la ÚNICA que puede escribir plan/isCoach en Firestore.
// El cliente llama a syncPlanFromRC() después de cada compra/restore.
// RevenueCat llama a revenueCatWebhook() en cancelaciones/renovaciones.
// sendPushToAthlete() envía notificaciones push al atleta vía FCM.

const { onCall, onRequest, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore }   = require("firebase-admin/firestore");
const { getMessaging }   = require("firebase-admin/messaging");
const { defineSecret }   = require("firebase-functions/params");
const crypto = require("crypto");

initializeApp();
const db = getFirestore();

const RC_SECRET = defineSecret("REVENUECAT_SECRET_KEY");

// ID de tu proyecto en RevenueCat (visible en la URL: app.revenuecat.com/projects/84ec7b14/...)
const RC_PROJECT_ID = "84ec7b14";

// Mapeo de entitlement IDs internos de RC → nombre del plan
// Obtenido de: GET /v2/projects/84ec7b14/entitlements
const ENTITLEMENT_ID_MAP = {
  "entl1ba2698490": "coach",
  "entl1d6a242a41": "pro",
};

// Jerarquía de planes: mayor índice = mayor valor
const PLAN_RANK = { free: 0, pro: 1, coach: 2, gym: 3 };

// ── Helper: detectar plan desde active_entitlements de RC API V2 ─────────────
//
// V2 devuelve: { items: [ { entitlement_id, expires_at } ] }
// Usamos ENTITLEMENT_ID_MAP para convertir el ID interno al nombre del plan.

function detectPlanV2(entitlements) {
  const items = entitlements?.items || [];

  const isActive = (planName) => {
    const entitlementId = Object.keys(ENTITLEMENT_ID_MAP).find(
      id => ENTITLEMENT_ID_MAP[id] === planName
    );
    if (!entitlementId) return false;

    const item = items.find(e => e.entitlement_id === entitlementId);
    if (!item) return false;
    if (!item.expires_at) return true;
    return new Date(item.expires_at) > new Date();
  };

  if (isActive("gym"))   return "gym";
  if (isActive("coach")) return "coach";
  if (isActive("pro"))   return "pro";
  return "free";
}

// ── Helper: llamar a RC API V2 ────────────────────────────────────────────────

async function fetchRCSubscriber(uid, apiKey) {
  const url = `https://api.revenuecat.com/v2/projects/${RC_PROJECT_ID}/customers/${uid}/active_entitlements`;
  const res = await fetch(url, {
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type":  "application/json",
    },
  });

  if (!res.ok) {
    const body = await res.text();
    console.error(`[RC API V2] ${res.status} para uid=${uid}:`, body);
    throw new Error(`RC API ${res.status}`);
  }

  const data = await res.json();
  return data || { items: [] };
}

// ── Helper: escribir plan en Firestore (operación privilegiada) ──────────────

async function applyPlanToFirestore(uid, plan, { allowDowngrade = true } = {}) {
  const isCoach = ["coach", "gym"].includes(plan);

  if (!allowDowngrade && plan === "free") {
    const currentSnap = await db.collection("users").doc(uid).get();
    const currentPlan = currentSnap.exists ? (currentSnap.data()?.plan || "free") : "free";
    const currentRank = PLAN_RANK[currentPlan] ?? 0;
    const newRank     = PLAN_RANK[plan] ?? 0;

    if (currentRank > newRank) {
      console.log(`[applyPlanToFirestore] ⚠️ Downgrade bloqueado: ${currentPlan} → ${plan} para uid=${uid}`);
      return { plan: currentPlan, isCoach: ["coach", "gym"].includes(currentPlan) };
    }
  }

  await db.collection("users").doc(uid).set({ plan, isCoach }, { merge: true });

  if (isCoach) {
    const coachRef  = db.collection("coaches").doc(uid);
    const coachSnap = await coachRef.get();
    const existing  = coachSnap.exists ? coachSnap.data() : {};

    const code = existing.code
      || Math.random().toString(36).slice(2, 8).toUpperCase();

    await coachRef.set({
      uid,
      athletes:  existing.athletes  || {},
      createdAt: existing.createdAt || new Date().toISOString().slice(0, 10),
      code,
    }, { merge: true });
  }

  return { plan, isCoach };
}

// ── Helper: enviar push a un usuario por su UID ──────────────────────────────

async function sendPushToUid(uid, title, body, data = {}) {
  try {
    const userSnap = await db.collection("users").doc(uid).get();
    if (!userSnap.exists) return { ok: false, reason: "user_not_found" };

    const fcmToken = userSnap.data()?.fcmToken;
    if (!fcmToken) return { ok: false, reason: "no_fcm_token" };

    await getMessaging().send({
      token: fcmToken,
      notification: { title, body },
      data: Object.fromEntries(
        Object.entries(data).map(([k, v]) => [k, String(v)])
      ),
      android: {
        priority: "high",
        notification: {
          channelId: "beast_default",
          sound: "default",
          icon: "ic_notification",
          color: "#e8ff00",
        },
      },
    });

    return { ok: true };
  } catch (e) {
    console.error("[sendPushToUid] ERROR:", e.code, e.message);
    if (e.code === "messaging/registration-token-not-registered") {
      await db.collection("users").doc(uid).set({ fcmToken: null }, { merge: true });
    }
    return { ok: false, reason: e.code };
  }
}

// ── sendPushToAthlete ─────────────────────────────────────────────────────────

exports.sendPushToAthlete = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Debes iniciar sesión.");
  }

  const { athleteUid, type, routineName, message, coachName } = request.data || {};

  if (!athleteUid || !type) {
    throw new HttpsError("invalid-argument", "Faltan parámetros requeridos.");
  }

  const coachSnap = await db.collection("coaches").doc(request.auth.uid).get();
  if (!coachSnap.exists) {
    throw new HttpsError("permission-denied", "No eres coach.");
  }
  const coachData = coachSnap.data();
  if (!coachData?.athletes?.[athleteUid]) {
    throw new HttpsError("permission-denied", "Este atleta no es tuyo.");
  }

  let title, body, data;

  if (type === "routine_assigned") {
    title = "💪 Nueva rutina asignada";
    body  = routineName
      ? `${coachName || "Tu coach"} te asignó: ${routineName}`
      : `${coachName || "Tu coach"} te asignó una nueva rutina`;
    data  = { type, routineName: routineName || "" };

  } else if (type === "coach_feedback") {
    title = "💬 Feedback de tu coach";
    body  = message || `${coachName || "Tu coach"} dejó un comentario en tu sesión`;
    data  = { type, message: message || "" };

  } else {
    throw new HttpsError("invalid-argument", `Tipo desconocido: ${type}`);
  }

  const result = await sendPushToUid(athleteUid, title, body, data);
  console.log(`[sendPushToAthlete] type=${type} athleteUid=${athleteUid} result=`, result);
  return result;
});

// ── saveFcmToken ──────────────────────────────────────────────────────────────

exports.saveFcmToken = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Debes iniciar sesión.");
  }
  const { token } = request.data || {};
  if (!token || typeof token !== "string") {
    throw new HttpsError("invalid-argument", "Token inválido.");
  }

  await db.collection("users").doc(request.auth.uid).set(
    { fcmToken: token, fcmUpdatedAt: new Date().toISOString() },
    { merge: true }
  );

  console.log(`[saveFcmToken] uid=${request.auth.uid} token guardado`);
  return { ok: true };
});

// ── syncPlanFromRC ────────────────────────────────────────────────────────────

exports.syncPlanFromRC = onCall(
  { secrets: [RC_SECRET] },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "Debes iniciar sesión.");
    }

    const uid = request.auth.uid;

    let entitlements;
    try {
      entitlements = await fetchRCSubscriber(uid, RC_SECRET.value());
    } catch (e) {
      console.error("[syncPlanFromRC] Error al consultar RC:", e.message);
      throw new HttpsError("internal", "Error al verificar suscripción.");
    }

    const plan = detectPlanV2(entitlements);
    console.log(`[syncPlanFromRC] uid=${uid} plan=${plan}`);

    const result = await applyPlanToFirestore(uid, plan, { allowDowngrade: false });
    return result;
  }
);

// ── revenueCatWebhook ─────────────────────────────────────────────────────────

exports.revenueCatWebhook = onRequest(
  { secrets: [RC_SECRET] },
  async (req, res) => {
    if (req.method !== "POST") {
      res.status(405).send("Method Not Allowed");
      return;
    }

    const event = req.body;
    if (!event?.event?.app_user_id) {
      res.status(400).send("Bad Request");
      return;
    }

    const uid       = event.event.app_user_id;
    const eventType = event.event.type;

    console.log(`[rcWebhook] event=${eventType} uid=${uid}`);

    const relevantEvents = [
      "INITIAL_PURCHASE", "RENEWAL", "PRODUCT_CHANGE",
      "CANCELLATION", "EXPIRATION", "BILLING_ISSUE",
      "SUBSCRIBER_ALIAS", "TRANSFER",
      "NON_RENEWING_PURCHASE",
    ];

    if (!relevantEvents.includes(eventType)) {
      res.status(200).send("Ignored");
      return;
    }

    try {
      const entitlements = await fetchRCSubscriber(uid, RC_SECRET.value());
      const plan         = detectPlanV2(entitlements);

      await applyPlanToFirestore(uid, plan, { allowDowngrade: true });
      console.log(`[rcWebhook] ✅ uid=${uid} → plan=${plan}`);
      res.status(200).send("OK");
    } catch (e) {
      console.error("[rcWebhook] error:", e);
      res.status(500).send("Internal Error");
    }
  }
);